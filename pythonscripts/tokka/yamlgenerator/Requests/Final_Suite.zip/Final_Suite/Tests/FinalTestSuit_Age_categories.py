import pymysql
import unittest
import requests
import os
import sys
import xmlrunner
import logging

logger = logging.getLogger()
logger.level = logging.DEBUG
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)

class TestAgeCategories(unittest.TestCase):

    def get_value_from_config(self):
        self.configlist = []
        with open("C://Users//SC057441//Desktop//Any//pythonscripts//tokka//yamlgenerator//Requests//Final_Suite//Resource//Config_age_categories.txt", "r") as readconfigfile:
            for line in readconfigfile:
                if line.startswith('URL'):
                    cleanedline = line.strip()
                    split = cleanedline.split('=')
                    self.configlist.append(split[1])
                elif line.startswith('DB1'):
                    cleanedline = line.strip()
                    split = cleanedline.split('=')
                    self.configlist.append(split[1])
                elif line.startswith('UN'):
                    cleanedline = line.strip()
                    split = cleanedline.split('=')
                    self.configlist.append(split[1])
                elif line.startswith('PWD'):
                    cleanedline = line.strip()
                    split = cleanedline.split('=')
                    self.configlist.append(split[1])
                elif line.startswith('DBN'):
                    cleanedline = line.strip()
                    split = cleanedline.split('=')
                    self.configlist.append(split[1])
            return self.configlist


    def setUp(self):
        self.set_up_list = self.get_value_from_config()
        self.GET_URL = self.set_up_list[0]
        self.oAuth = self.Auth()
        self.header = {'Authorization': self.oAuth, 'Content-Type':'application/json'}
        self.db = pymysql.connect(self.set_up_list[1], self.set_up_list[2], self.set_up_list[3],self.set_up_list[4])
        self.cursor = self.db.cursor()

    def Auth(self):
        os.system("java -jar auth-header-1.3.jar -k c0c11d7a-48c1-461d-8be9-56e9fb60b28f -s Jjftdr7d_z7kjM1_GTXKskfQZs9aCD1l > oAuthKey.txt")
        with open("oAuthKey.txt","r") as oAuthFile:
            for line in oAuthFile:
                cleanedLine = line.strip()
                if cleanedLine:  # is not empty
                    #print("Recieved the token")
                    oAuth = cleanedLine
        logging.getLogger().info("returning oAuth Value")
        return oAuth

    def test_rest_api_error(self):
        oAuth = '2'
        header1 = {'Authorization': oAuth}
        session = requests.Session()
        self.res = requests.get(self.GET_URL, headers=header1)
        self.response = self.res.status_code
        self.assertEqual(str(self.response), '401')

    def test_rest_api_NotFound(self):
        self.GET_URL_1 = 'http://services.devhealtheintent.net/rc-dashboard-config-service/age_categorie'
        self.res = requests.get(self.GET_URL_1, headers=self.header)
        self.response = self.res.status_code
        self.assertEqual(str(self.response), '404')

    def test_rest_api_Conflicts(self):
        self.GET_URL2 = 'http://services.devhealtheintent.net/rc-dashboard-config-service/config_items'
        self.res = requests.post(self.GET_URL2, headers=self.header)
        self.response = self.res.status_code
        self.assertEqual(str(self.response), '409')

    def test_rest_api_badRequest(self):
        self.data1 = {"age_categories": "[{\"id\": 1,\"client_id\": \"DEFAULT\",\"age_category\":\"366+\",\"begin_age\": 50,\"end_age\": 100,\"sort_order\": 2}]"}
        self.res = requests.put(self.GET_URL, headers=self.header, data=self.data1)
        self.response = self.res.status_code
        self.assertEqual(str(self.response), '400')

    def test_rest_api_noContent(self):
        self.data1 = {"age_categories": "[{\"id\": 1,\"client_id\": \"DEFAULT\",\"age_category\":\"366+\",\"begin_age\": 50,\"end_age\": 100,\"sort_order\": 2}]"}
        self.res = requests.put(self.GET_URL, headers=self.header, json=self.data1)
        self.response = self.res.status_code
        self.assertEqual(str(self.response), '204')

    def test_rest_api_invalidRecord(self):
        self.data1 = {"age_categories": "[{\"id\": 1,\"client_id\": \"DEFAULT\",\"age_category\":\"366+\",\"begin_age\": 50,\"end_age\": 100,\"sort_order\": 2}]"}
        self.res = requests.post(self.GET_URL, headers=self.header, json=self.data1)
        self.response = self.res.status_code
        self.assertEqual(str(self.response), '404')

    def test_rest_api_putRequest(self):
        self.data1 = {"age_categories": "[{\"id\": 1,\"client_id\": \"DEFAULT\",\"age_category\":\"366+\",\"begin_age\": 50,\"end_age\": 100,\"sort_order\": 2}]"}
        self.res = requests.put(self.GET_URL, headers=self.header, json=self.data1)
        self.response = self.res.status_code
        self.assertEqual(str(self.response), '200')

    def test_rest_api_getRequest(self):
        self.tempdict={}
        self.res = requests.get(self.GET_URL, headers=self.header)
        for self.i in self.res.json():
            for self.k, self.v in self.i.items():
                if self.k == 'age_category':
                    self.tempdict.setdefault(self.k, []).append(self.v)
                elif self.k == 'begin_age':
                    self.tempdict.setdefault(self.k, []).append(self.v)
                elif self.k == 'end_age':
                    self.tempdict.setdefault(self.k, []).append(self.v)
                elif self.k == 'sort_order':
                    self.tempdict.setdefault(self.k, []).append(self.v)
        logging.getLogger().info("The o/p from API is here")
        logging.getLogger().info(self.tempdict)
        # SQL DB Connection and fetching and disconnection as well
        self.cursor.execute("SELECT age_category,begin_age,end_age,sort_order FROM age_categories WHERE client_id='50187c3d-b72c-4f7a-9a34-b2abe35be868'")
        self.data = set(self.cursor.fetchall())
        self.col_names = [i[0] for i in self.cursor.description]
        self.some_dict = {self.col_names[0]: [self.x[0] for self.x in self.data],
                     self.col_names[1]: [self.x[1] for self.x in self.data],
                     self.col_names[2]: [self.x[2] for self.x in self.data],
                     self.col_names[3]: [self.x[3] for self.x in self.data], }
        logging.getLogger().info("The o/p from Data base is here")
        logging.getLogger().info(self.some_dict)
        self.db.close()
        logging.getLogger().info("Now validating things......")
        # validation of the data from DB with the api
        for self.k, self.v in self.tempdict.items():
            if self.k == 'age_category':
                self.l1 = self.tempdict[self.k]
                self.l2 = self.some_dict[self.k]
                self.assertEqual(set(self.l2).issuperset(set(self.l1)), True)

            elif self.k == 'begin_age':
                self.l1 = self.tempdict[self.k]
                self.l2 = self.some_dict[self.k]
                self.assertEqual(set(self.l2).issuperset(set(self.l1)), True)

            elif self.k == 'end_age':
                self.l1 = self.tempdict[self.k]
                self.l2 = self.some_dict[self.k]
                self.assertEqual(set(self.l2).issuperset(set(self.l1)), True)

            elif self.k == 'sort_order':
                self.l1 = self.tempdict[self.k]
                self.l2 = self.some_dict[self.k]
                self.assertEqual(set(self.l2).issuperset(set(self.l1)), True)
        logging.getLogger().info("validation done all are matching.....")

if __name__ == '__main__':
    unittest.main(testRunner=xmlrunner.XMLTestRunner(output="./python_unittests_xml"))